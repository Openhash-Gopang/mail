// 도우미가 받아 온 서류 파일을 나비웹 화면으로 보내기 전의 검사와 변환(브라우저 API 없이 시험할 수 있게 따로 둔다).
// 파일 내용과 주소는 AI 모델로 보내지 않는다. 확장이 직접 받아 나비웹 탭으로만 넘기고, 서류에 넣을지는 나비웹 화면이 사용자에게 묻는다.
export const MAX_BYTES = 10 * 1024 * 1024;   // 나비웹 다리(bridge.js)의 14MB(base64) 한도 안쪽

const SECOND_LEVEL = new Set(['go', 'co', 'or', 'ne', 're', 'pe', 'ac', 'hs', 'ms', 'es', 'sc', 'kg']);
// 같은 기관 사이트인지(예: www.gov.kr 과 file.gov.kr) 대략 가린다. 서로 다른 기관의 주소로는 보내지 않는다.
export function baseDomain(host) {
  const p = String(host || '').toLowerCase().split('.').filter(Boolean);
  if (p.length <= 2) return p.join('.');
  const n = p[p.length - 1] === 'kr' && SECOND_LEVEL.has(p[p.length - 2]) ? 3 : 2;
  return p.slice(-n).join('.');
}
export function checkFileUrl(fileUrl, tabUrl) {
  let u, t;
  try { u = new URL(fileUrl); } catch { return { ok: false, msg: '파일 주소를 읽지 못했습니다.' }; }
  if (u.protocol !== 'https:') return { ok: false, msg: u.protocol === 'blob:' || u.protocol === 'data:' ? '이 사이트는 화면 안에서 만든 파일(blob/data)로 내려 주어 자동으로 가져올 수 없습니다.' : 'https 주소의 파일만 가져올 수 있습니다.' };
  try { t = new URL(tabUrl); } catch { return { ok: false, msg: '작업 중인 탭의 주소를 확인하지 못했습니다.' }; }
  if (baseDomain(u.hostname) !== baseDomain(t.hostname)) return { ok: false, msg: `작업 중인 사이트(${t.hostname})와 다른 사이트(${u.hostname})의 파일은 가져오지 않습니다.` };
  return { ok: true, url: u.href, host: u.hostname };
}

const OK_MIME = /^(application\/pdf|image\/(png|jpe?g|gif|webp|tiff?|bmp)|application\/(x-hwp|haansofthwp|vnd\.hancom\.hwp|vnd\.hancom\.hwpx|msword|vnd\.ms-[a-z.]+|vnd\.openxmlformats-officedocument\.[a-z.]+|zip|octet-stream)|binary\/octet-stream)$/i;
const OK_EXT = /\.(pdf|png|jpe?g|gif|webp|tiff?|bmp|hwp|hwpx|docx?|xlsx?|pptx?|zip)$/i;

export function parseDisposition(h) {
  const s = String(h || '');
  const star = /filename\*\s*=\s*(?:UTF-8|utf-8)''([^;]+)/.exec(s);
  if (star) { try { return decodeURIComponent(star[1].trim()); } catch { /* 아래로 */ } }
  const q = /filename\s*=\s*"([^"]+)"/.exec(s) || /filename\s*=\s*([^;]+)/.exec(s);
  return q ? q[1].trim() : '';
}
export function safeName(name, mime, url) {
  let n = String(name || '').replace(/[\\/:*?"<>|\u0000-\u001f]+/g, '_').trim();
  if (!n) { try { n = decodeURIComponent(new URL(url).pathname.split('/').pop() || ''); } catch { n = ''; } n = n.replace(/[\\/:*?"<>|\u0000-\u001f]+/g, '_').trim(); }
  if (!n) n = '서류';
  if (!OK_EXT.test(n)) n += /pdf/i.test(mime) ? '.pdf' : /png/i.test(mime) ? '.png' : /jpe?g/i.test(mime) ? '.jpg' : '';
  return n.slice(0, 120);
}
export function toBase64(u8) {
  let s = ''; const step = 0x8000;
  for (let i = 0; i < u8.length; i += step) s += String.fromCharCode.apply(null, u8.subarray(i, i + step));
  return btoa(s);
}

// 로그인한 사용자의 브라우저 세션(쿠키)으로 파일을 받는다. 화면(HTML)이나 오류 응답은 서류가 아니므로 돌려보낸다.
export async function fetchForNavi(fileUrl, tabUrl, fetchImpl = fetch) {
  const c = checkFileUrl(fileUrl, tabUrl);
  if (!c.ok) return c;
  let r;
  try { r = await fetchImpl(c.url, { credentials: 'include', redirect: 'follow' }); } catch (e) { return { ok: false, msg: '파일을 받지 못했습니다: ' + (e && e.message ? e.message : e) }; }
  if (!r.ok) return { ok: false, msg: `파일을 받지 못했습니다(응답 ${r.status}).` };
  const rc = checkFileUrl(r.url || c.url, tabUrl);   // 다른 사이트로 넘어갔으면 거부
  if (!rc.ok) return rc;
  const mime = String((r.headers && r.headers.get && r.headers.get('content-type')) || '').split(';')[0].trim().toLowerCase();
  const name = safeName(parseDisposition(r.headers && r.headers.get && r.headers.get('content-disposition')), mime, c.url);
  if (!OK_MIME.test(mime) && !(mime === '' && OK_EXT.test(name))) return { ok: false, msg: `서류 파일이 아닌 응답입니다(${mime || '형식 없음'}). 로그인이 풀렸거나 오류 화면일 수 있습니다. 이 링크는 파일이 아니라 화면입니다. 같은 화면(또는 처리완료 상세 화면)의 "문서출력"·"저장"·"다운로드" 단추를 눌러 파일을 내려받은 뒤 ref 없이 send_file_to_navi 를 다시 부르세요. 문서출력이 새 창을 열면 그 창에서 저장 단추를 누릅니다.` };
  const len = Number(r.headers && r.headers.get && r.headers.get('content-length')) || 0;
  if (len > MAX_BYTES) return { ok: false, msg: `파일이 너무 큽니다(${Math.round(len / 1048576)}MB, 최대 10MB).` };
  const buf = new Uint8Array(await r.arrayBuffer());
  if (!buf.length) return { ok: false, msg: '받은 파일이 비어 있습니다.' };
  if (buf.length > MAX_BYTES) return { ok: false, msg: `파일이 너무 큽니다(${Math.round(buf.length / 1048576)}MB, 최대 10MB).` };
  if (/pdf/i.test(mime) && String.fromCharCode(...buf.subarray(0, 5)) !== '%PDF-') return { ok: false, msg: 'PDF 로 표시됐지만 PDF 파일이 아닙니다.' };
  return { ok: true, name, mime: mime || 'application/octet-stream', b64: toBase64(buf), size: buf.length };
}

// 방금 받은 파일(내려받기 기록)에서 주소를 고른다. 10분 안에 끝난 것 중 가장 최근 것.
export function pickDownload(items, now = Date.now()) {
  const list = (Array.isArray(items) ? items : []).filter((d) => d && d.state === 'complete' && !d.error && now - Date.parse(d.endTime || d.startTime || 0) < 10 * 60 * 1000);
  list.sort((a, b) => Date.parse(b.endTime || b.startTime || 0) - Date.parse(a.endTime || a.startTime || 0));
  const d = list[0];
  if (!d) return { ok: false, msg: '최근 10분 안에 내려받은 파일이 없습니다. 내려받기 단추나 링크를 먼저 누르거나, 링크 요소의 ref 를 주세요.' };
  const url = d.finalUrl || d.url || '';
  if (!/^https:/i.test(url)) return { ok: false, msg: '내려받은 파일이 화면 안에서 만든 파일(blob/data)이라 자동으로 가져올 수 없습니다. 사용자가 저장한 파일을 나비웹에 직접 올려야 합니다.' };
  return { ok: true, url, name: String(d.filename || '').split(/[\\/]/).pop() };
}

// 문서 보기(뷰어) 창에서 문서를 직접 가져온다. 정부24 "문서출력" 창(plus.gov.kr/ezpdfwv/viewer)처럼 내려받기 링크도 저장 파일도 없이
// 화면 안에서 PDF 를 그려 주는 경우를 위한 것으로, 그 화면이 불러온 주소 중 PDF 를 찾아 로그인된 세션으로 다시 받는다.
// 페이지 안에서 실행된다(자체 완결 — 바깥 변수를 쓰지 않는다). 같은 사이트의 https 주소만, 내용이 %PDF- 로 시작할 때만 받는다.
export async function grabPdfInPage(maxBytes) {
  const base = (h) => h.split('.').slice(-2).join('.');
  const mine = base(location.hostname);
  const bad = /\.(js|css|png|jpe?g|gif|svg|ico|woff2?|ttf|eot|map|json|html?)(\?|$)/i;
  const urls = [];
  try { performance.getEntriesByType('resource').forEach((e) => urls.push(e.name)); } catch { /* 읽을 수 없음 */ }
  const cands = [...new Set(urls)].filter((u) => { try { const x = new URL(u); return x.protocol === 'https:' && base(x.hostname) === mine && !bad.test(x.pathname + x.search); } catch { return false; } }).reverse().slice(0, 40);
  let big = false;
  for (const u of cands) {
    try {
      const r = await fetch(u, { credentials: 'include' });
      if (!r.ok) continue;
      const buf = new Uint8Array(await r.arrayBuffer());
      if (buf.length < 100 || String.fromCharCode(buf[0], buf[1], buf[2], buf[3], buf[4]) !== '%PDF-') continue;
      if (buf.length > maxBytes) { big = true; continue; }
      let s = ''; for (let i = 0; i < buf.length; i += 0x8000) s += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
      return { ok: true, size: buf.length, b64: btoa(s) };
    } catch { /* 다음 후보 */ }
  }
  return { ok: false, msg: big ? '문서가 너무 큽니다(최대 10MB).' : '이 화면이 불러온 PDF 를 찾지 못했습니다.' };
}

// "인쇄" 단추만 있는 뷰어(정부24 문서출력 창)용: 사용자가 인쇄 창에서 "PDF 로 저장"을 고르는 것과 같은 결과를 확장이 직접 만든다.
// 탭을 잠깐 디버거에 붙여 Page.printToPDF 로 화면(인쇄용 스타일 적용)을 PDF 로 만들고 바로 뗀다. 사본이므로 원본 파일과 같지 않을 수 있다.
export async function printTabToPdf(dbg, tabId, maxBytes = MAX_BYTES) {
  const target = { tabId };
  try { await dbg.attach(target, '1.3'); } catch (e) { return { ok: false, msg: '화면을 PDF 로 만들지 못했습니다(디버거 연결 실패: ' + (e && e.message ? e.message : e) + ').' }; }
  try {
    const r = await dbg.sendCommand(target, 'Page.printToPDF', { printBackground: true, preferCSSPageSize: true, paperWidth: 8.27, paperHeight: 11.69 });
    const b64 = r && r.data ? String(r.data) : '';
    if (!b64) return { ok: false, msg: '화면을 PDF 로 만들지 못했습니다(빈 결과).' };
    const size = Math.floor(b64.length * 3 / 4);
    if (size > maxBytes) return { ok: false, msg: `PDF 가 너무 큽니다(${Math.round(size / 1048576)}MB, 최대 10MB).` };
    return { ok: true, size, b64 };
  } catch (e) {
    return { ok: false, msg: '화면을 PDF 로 만들지 못했습니다: ' + (e && e.message ? e.message : e) };
  } finally { try { await dbg.detach(target); } catch { /* 이미 떼어짐 */ } }
}

// 사람이 마우스를 누르는 것과 같은 입력(이동 → 누름 → 잠깐 유지 → 뗌)을 브라우저가 직접 보낸다. 페이지 스크립트의 el.click() 과 달리 "사용자 조작"으로 인정되어
// 새 창 열기(window.open)가 팝업 차단에 막히지 않고, 누름·뗌 사이에 반응하는 단추도 동작한다. 탭을 디버거에 잠깐 붙였다가 바로 뗀다.
export async function debuggerClick(dbg, tabId, x, y, sleep = (ms) => new Promise((r) => setTimeout(r, ms)), holdMs = 120) {
  const target = { tabId };
  try { await dbg.attach(target, '1.3'); } catch (e) { return { ok: false, msg: '마우스 입력을 보내지 못했습니다(디버거 연결 실패).' }; }
  try {
    const send = (type, extra) => dbg.sendCommand(target, 'Input.dispatchMouseEvent', { type, x, y, button: 'left', ...extra });
    await send('mouseMoved', { buttons: 0 });
    await sleep(60);
    await send('mousePressed', { buttons: 1, clickCount: 1 });
    await sleep(holdMs);
    await send('mouseReleased', { buttons: 0, clickCount: 1 });
    await sleep(250);
    return { ok: true };
  } catch (e) {
    return { ok: false, msg: '마우스 입력을 보내지 못했습니다: ' + (e && e.message ? e.message : e) };
  } finally { try { await dbg.detach(target); } catch { /* 이미 떼어짐 */ } }
}
